import pygame
import random
from pygame import mixer

#Some constants before we get going

WIDTH = 1024
HEIGHT = 576
STAGE = pygame.display.set_mode((WIDTH,HEIGHT))
CLOCK = pygame.time.Clock()
FPS = 60

#Starting position for our character
STARTX = 0              # Left side of screen
STARTY = HEIGHT / 2     # Middle of screen top-to-bottom

#Player movement
MOVESPEED = 8
MOBSPEED = 3

#Colors for text later
RED = (255, 0, 0)
WHITE = (255, 255, 255)

#Images to use
BG = pygame.image.load("starsbg.gif")   
SHIP = pygame.image.load("spaceship.gif")
ENEMY = pygame.image.load("missile.png")
ICON = pygame.image.load("game_icon.png")
CRASH = pygame.image.load("explosion.gif")

def redraw(player, enemies, score):
    STAGE.blit(BG, (0,0))       # Place the star background at x,y = 0,0
    STAGE.blit(SHIP, (STARTX, player.y))    # Place the player at STARTX (0) and Y postion equal to whatever from keypresses

    for i in enemies:
        STAGE.blit(ENEMY, (i.x, i.y))

    refresh_score(score)
    pygame.display.update()     # Redraw the stage with the above things in place

def refresh_score(score):
    myfont = pygame.font.SysFont(None, 36, bold=True)
    game_text = myfont.render(f"SCORE: {score}", True, WHITE)
    STAGE.blit(game_text, (WIDTH - game_text.get_width(), 10))
    
def create_enemy():
    y_pos = random.randint(0,HEIGHT)
    return ENEMY.get_rect(center=(WIDTH, y_pos))

def collision_check(missile, player):
    return missile.colliderect(player)

def draw_explosion(player):
    #Add explosion graphic
    STAGE.blit(CRASH, (STARTX - 100, player.y - 100))

    #Add game over text

    my_font = pygame.font.SysFont(None, 48, bold=True)
    game_text = my_font.render("GAME OVER", False, RED)
    STAGE.blit(game_text, (WIDTH / 2 - game_text.get_width() / 2, HEIGHT / 2))

    #update display and wait so we can see something happen before exit
    pygame.display.update()
    pygame.time.wait(1500)

def main():
    pygame.init()
    mixer.init()
    mixer.music.load("explode.mp3")
    pygame.display.set_caption("Spaceship Dodge Game")
    pygame.display.set_icon(ICON)

    score = 0
    enemies = []

    player = SHIP.get_rect(center=(STARTX,STARTY))
    
    #missile_speed = MOBSPEED

    #Initialize main game loop
    keep_playing = True

    # Main loop for the game to keep going
    while keep_playing == True:

        new_y = player.y    # set the player's position
        CLOCK.tick(FPS)     # Update needed for proper redraw

        multiplier = 1 + ((score // 10) * 0.2)

        # ever 23ish ticks, go get a new enemy and put it
        # on screen and in our enemy list

        if (pygame.time.get_ticks() % 23) == 0:
            new_enemy = create_enemy()
            STAGE.blit(ENEMY, (new_enemy.x, new_enemy.y))
            enemies.append(new_enemy)

        # Move all enemies from Righ to Left
        for missile in enemies:
            if missile.x > -missile.width:
                # missile.x -= MOBSPEED
                missile.x -= MOBSPEED * multiplier

                #check for collision with player
                if collision_check(missile, player):
                    keep_playing = False
                    mixer.music.play()
                    draw_explosion(player)
            else:
                enemies.remove(missile) #if we're here, missile is off the screen (left edge)
                score += 1

        # Here we need to add commands to press keys
        # And have the game do something - like move our character
        keys_pressed = pygame.key.get_pressed()

        if keys_pressed[pygame.K_ESCAPE]:
            keep_playing = False

        if keys_pressed[pygame.K_UP]:
            player.y -= MOVESPEED

        if keys_pressed[pygame.K_DOWN]:
            player.y += MOVESPEED

        #If we hit the top, dont go negative x
        if player.y < 0:
            player.y = 0

        #If we hit the bottom accounting for ship height    
        if (player.y + player.height) >= HEIGHT:
            player.y = HEIGHT - player.height
            
        # Use this code to wrap the screen.
        # if player.y >= HEIGHT:
        #     player.y = 0


        # Pygame has an event system.
        # If it "hears" a "QUIT" event (window closed), exit gracefully
        for event in pygame.event.get():  
            if event.type == pygame.QUIT:
                keep_playing = False
            
        redraw (player,enemies, score)       

    # This is called after our while loop ends
    pygame.quit()

main()
